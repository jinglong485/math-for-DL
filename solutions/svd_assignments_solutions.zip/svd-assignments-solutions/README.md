# Reference solutions — SVD & Pseudo-Inverse coding assignments

Open this only after a genuine attempt at an assignment.

`svd_assignments/` here is a drop-in replacement for the folder of the same
name in the starter kit. To check a single module, copy just that file over
your own (keep a backup of yours first) and run, for example,

```bash
python grade.py a4
```

With all six reference modules in place the test suite scores 100 / 100.
These are one correct way to solve each assignment, not the only one: any
implementation that passes the tests without `numpy.linalg` is a valid answer.
