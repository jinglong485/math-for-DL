"""
Assignment 3 -- Eigenvalues of symmetric matrices.

Textbook: Chapters 4-5.   Lab Manual: Part 3.

Rules: NumPy arrays, element-wise arithmetic and @ are allowed.
Nothing from numpy.linalg (or scipy).
"""
import numpy as np

from .a1_vectors import norm


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def rayleigh_quotient(S, x):
    """Return x^T S x / x^T x as a float.

    Raises:
        ValueError: if x is the zero vector.
    """
    S = _as_float_matrix(S)
    x = np.asarray(x, dtype=float).ravel()
    xx = x @ x
    if xx == 0.0:
        raise ValueError("x must be non-zero")
    return float(x @ (S @ x) / xx)


def power_iteration(S, x0=None, tol=1e-12, max_iter=10_000):
    """Dominant eigenpair of a symmetric matrix by power iteration.

    Args:
        S: (n x n) symmetric matrix with |lambda_1| > |lambda_2|.
        x0: optional starting vector (default: a fixed random vector).
        tol: stop when successive Rayleigh quotients differ by <= tol * max(1, |lambda|).
        max_iter: maximum number of iterations.
    Returns:
        (lam, v): eigenvalue estimate (float) and unit eigenvector (1-D array).
    """
    S = _as_float_matrix(S)
    n = S.shape[0]
    if x0 is None:
        x0 = np.random.default_rng(12345).standard_normal(n)
    x = np.asarray(x0, dtype=float).ravel()
    x = x / norm(x)
    lam = rayleigh_quotient(S, x)
    for _ in range(max_iter):
        y = S @ x
        ny = norm(y)
        if ny == 0.0:
            return 0.0, x
        x = y / ny
        new = rayleigh_quotient(S, x)
        if abs(new - lam) <= tol * max(1.0, abs(new)):
            return new, x
        lam = new
    return lam, x


def jacobi_eigh(S, tol=1e-14, max_sweeps=60):
    """All eigenvalues and eigenvectors of a real symmetric matrix (cyclic Jacobi).

    Returns:
        (eigvals, V): eigvals is a 1-D array sorted in DECREASING order;
        V is orthogonal with V[:, i] the eigenvector for eigvals[i],
        so that S @ V == V * eigvals.
    Raises:
        ValueError: if S is not square or not symmetric
                    (|S - S^T| > 1e-10 * max(1, max|S|)).
    """
    A = _as_float_matrix(S)
    n = A.shape[0]
    if A.shape != (n, n):
        raise ValueError("matrix must be square")
    if np.max(np.abs(A - A.T), initial=0.0) > 1e-10 * max(1.0, np.max(np.abs(A), initial=0.0)):
        raise ValueError("matrix must be symmetric")
    A = (A + A.T) / 2
    V = np.eye(n)
    scale = np.sqrt(np.sum(A * A)) or 1.0
    for _ in range(max_sweeps):
        O = A - np.diag(np.diag(A))
        if np.sqrt(np.sum(O * O)) <= tol * scale:
            break
        for p in range(n - 1):
            for q in range(p + 1, n):
                apq = A[p, q]
                if apq == 0.0:
                    continue
                theta = (A[q, q] - A[p, p]) / (2.0 * apq)
                if abs(theta) > 1e150:
                    t = 0.5 / theta
                else:
                    t = (1.0 if theta >= 0 else -1.0) / (abs(theta) + np.sqrt(theta * theta + 1.0))
                c = 1.0 / np.sqrt(t * t + 1.0)
                s = t * c
                Ap, Aq = A[:, p].copy(), A[:, q].copy()
                A[:, p], A[:, q] = c * Ap - s * Aq, s * Ap + c * Aq
                Ap, Aq = A[p, :].copy(), A[q, :].copy()
                A[p, :], A[q, :] = c * Ap - s * Aq, s * Ap + c * Aq
                A[p, q] = A[q, p] = 0.0
                Vp, Vq = V[:, p].copy(), V[:, q].copy()
                V[:, p], V[:, q] = c * Vp - s * Vq, s * Vp + c * Vq
    lam = np.diag(A).copy()
    order = np.argsort(lam)[::-1]
    return lam[order], V[:, order]


def spectral_reconstruct(eigvals, V):
    """Return V diag(eigvals) V^T = sum_i lambda_i v_i v_i^T."""
    V = _as_float_matrix(V)
    return (V * np.asarray(eigvals, dtype=float)) @ V.T


def classify_definiteness(S, tol=1e-10):
    """Classify a symmetric matrix by the signs of its eigenvalues.

    An eigenvalue counts as zero if |lambda| <= tol * max(1, max|lambda|).
    Returns exactly one of the strings
        "positive definite", "positive semidefinite",
        "negative definite", "negative semidefinite", "indefinite".
    The zero matrix counts as "positive semidefinite".
    """
    lam, _ = jacobi_eigh(S)
    thr = tol * max(1.0, float(np.max(np.abs(lam), initial=0.0)))
    pos = np.sum(lam > thr)
    neg = np.sum(lam < -thr)
    n = lam.size
    if neg == 0:
        return "positive definite" if pos == n else "positive semidefinite"
    if pos == 0:
        return "negative definite" if neg == n else "negative semidefinite"
    return "indefinite"
