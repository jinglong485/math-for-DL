"""
Assignment 4 -- The singular value decomposition.

Textbook: Chapters 6-7.   Lab Manual: Part 4.

Conventions (the same as numpy.linalg.svd):
  * functions return (U, s, Vt) where s is a 1-D array of the
    min(m, n) singular values in DECREASING order and Vt = V^T;
  * full_matrices=False -> U is (m x k), Vt is (k x n), k = min(m, n);
  * full_matrices=True  -> U is (m x m), Vt is (n x n), both orthogonal.
Singular vectors are only determined up to sign (and up to rotation for
repeated singular values), so the tests check properties, not entries.

Rules: nothing from numpy.linalg (or scipy).  You may import your own
functions from a1-a3 (e.g. jacobi_eigh, complete_basis).
"""
import numpy as np

from .a1_vectors import norm
from .a2_orthogonal import complete_basis
from .a3_eigen import jacobi_eigh

EPS = np.finfo(float).eps


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def svd_via_eig(A, full_matrices=False):
    """SVD by the textbook recipe: eigen-decompose A^T A (or A A^T if A is wide).

    sigma_i = sqrt(lambda_i), then u_i = A v_i / sigma_i for the non-zero
    sigma_i, then complete U (e.g. with complete_basis from A2).
    Eigenvalues lambda_i <= max(m, n) * EPS * lambda_1 count as zero (this
    method cannot resolve anything smaller); return their sigma_i as exactly 0.
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    if m < n:
        U, s, Vt = svd_via_eig(A.T, full_matrices)
        return Vt.T, s, U.T
    lam, V = jacobi_eigh(A.T @ A)
    lam1 = lam[0] if lam.size else 0.0
    r = int(np.sum(lam > max(m, n) * EPS * lam1)) if lam1 > 0 else 0
    s = np.sqrt(np.clip(lam, 0.0, None))
    U = np.zeros((m, r))
    for i in range(r):
        U[:, i] = A @ V[:, i] / s[i]
    U = complete_basis(U)
    s[r:] = 0.0
    if full_matrices:
        return U, s, V.T
    return U[:, :n], s, V.T


def svd_jacobi(A, full_matrices=False, tol=1e-15, max_sweeps=60):
    """SVD by one-sided Jacobi rotations on the columns of A.

    Must NOT form A^T A.  The tests require the smallest singular value of the
    Lauchli matrix [[1, 1], [1e-8, 0], [0, 1e-8]] to be correct to 1e-6
    relative accuracy -- the eigenvalue method cannot achieve that.
    Singular values <= max(m, n) * EPS * sigma_1 must be returned as exactly 0.
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    if m < n:
        U, s, Vt = svd_jacobi(A.T, full_matrices, tol, max_sweeps)
        return Vt.T, s, U.T
    W = A.copy()
    V = np.eye(n)
    for _ in range(max_sweeps):
        rotated = False
        for p in range(n - 1):
            for q in range(p + 1, n):
                alpha = W[:, p] @ W[:, p]
                beta = W[:, q] @ W[:, q]
                gamma = W[:, p] @ W[:, q]
                if gamma == 0.0 or abs(gamma) <= tol * np.sqrt(alpha * beta):
                    continue
                rotated = True
                zeta = (beta - alpha) / (2.0 * gamma)
                if abs(zeta) > 1e150:
                    t = 0.5 / zeta
                else:
                    t = (1.0 if zeta >= 0 else -1.0) / (abs(zeta) + np.sqrt(1.0 + zeta * zeta))
                c = 1.0 / np.sqrt(1.0 + t * t)
                s_ = c * t
                Wp, Wq = W[:, p].copy(), W[:, q].copy()
                W[:, p], W[:, q] = c * Wp - s_ * Wq, s_ * Wp + c * Wq
                Vp, Vq = V[:, p].copy(), V[:, q].copy()
                V[:, p], V[:, q] = c * Vp - s_ * Vq, s_ * Vp + c * Vq
        if not rotated:
            break
    s = np.array([norm(W[:, j]) for j in range(n)])
    order = np.argsort(s)[::-1]
    s, W, V = s[order], W[:, order], V[:, order]
    s1 = s[0] if s.size else 0.0
    r = int(np.sum(s > max(m, n) * EPS * s1)) if s1 > 0 else 0
    U = np.zeros((m, r))
    for i in range(r):
        U[:, i] = W[:, i] / s[i]
    U = complete_basis(U)
    s[r:] = 0.0
    if full_matrices:
        return U, s, V.T
    return U[:, :n], s, V.T


def singular_values(A):
    """Return the min(m, n) singular values of A in decreasing order."""
    return svd_jacobi(A)[1]


def svd_reconstruct(U, s, Vt):
    """Return U @ Sigma @ Vt, building the (rectangular) Sigma from s.

    Must work for both reduced and full factors, e.g. U (m x m), s (k,),
    Vt (n x n) with k = min(m, n).
    """
    U = _as_float_matrix(U)
    Vt = _as_float_matrix(Vt)
    s = np.asarray(s, dtype=float).ravel()
    k = s.size
    return (U[:, :k] * s) @ Vt[:k, :]


def matrix_rank(A, tol=None):
    """Numerical rank: the number of singular values > tol.

    Default tol = max(m, n) * EPS * sigma_1.  The zero matrix has rank 0.
    """
    A = _as_float_matrix(A)
    s = singular_values(A)
    if s.size == 0 or s[0] == 0.0:
        return 0
    if tol is None:
        tol = max(A.shape) * EPS * s[0]
    return int(np.sum(s > tol))


def four_subspaces(A, tol=None):
    """Orthonormal bases of the four fundamental subspaces, from the SVD.

    Returns a dict with keys
        "row"       (n x r)      basis of C(A^T)
        "null"      (n x (n-r))  basis of N(A)
        "column"    (m x r)      basis of C(A)
        "left_null" (m x (m-r))  basis of N(A^T)
    where r = matrix_rank(A, tol).  Each value is a 2-D array whose columns
    are orthonormal (an empty basis has shape (n, 0) or (m, 0)).
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    U, s, Vt = svd_jacobi(A, full_matrices=True)
    r = matrix_rank(A, tol)
    V = Vt.T
    return {"row": V[:, :r], "null": V[:, r:], "column": U[:, :r], "left_null": U[:, r:]}
