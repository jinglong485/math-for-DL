"""
Assignment 2 -- Orthogonality: Gram-Schmidt, Householder QR, projections.

Textbook: Chapter 3.   Lab Manual: Part 2.

Rules: NumPy arrays, element-wise arithmetic and @ are allowed.
Nothing from numpy.linalg (or scipy).  You may import your own
functions from a1_vectors.
"""
import numpy as np

from .a1_vectors import norm


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def gram_schmidt(A):
    """Reduced QR factorisation by MODIFIED Gram-Schmidt.

    Args:
        A: (m x n) array with linearly independent columns (m >= n).
    Returns:
        (Q, R): Q is (m x n) with orthonormal columns, R is (n x n) upper
        triangular with POSITIVE diagonal, and Q @ R == A.
    Raises:
        ValueError: if a column is (numerically) dependent on the previous
        ones, i.e. its remaining part has norm <= 1e-12 * (norm of the column).

    The tests check that orthogonality survives for a matrix with condition
    number 1e7 -- classical Gram-Schmidt fails that test, modified passes.
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    Q = np.zeros((m, n))
    R = np.zeros((n, n))
    for j in range(n):
        w = A[:, j].copy()
        for i in range(j):
            R[i, j] = Q[:, i] @ w
            w -= R[i, j] * Q[:, i]
        R[j, j] = norm(w)
        if R[j, j] <= 1e-12 * max(norm(A[:, j]), 1e-300):
            raise ValueError("columns are linearly dependent")
        Q[:, j] = w / R[j, j]
    return Q, R


def qr_householder(A):
    """Full QR factorisation by Householder reflections.

    Args:
        A: any (m x n) array.
    Returns:
        (Q, R): Q is (m x m) orthogonal, R is (m x n) upper triangular
        (exact zeros below the diagonal), and Q @ R == A.
    """
    R = _as_float_matrix(A)
    m, n = R.shape
    Q = np.eye(m)
    for k in range(min(m - 1, n)):
        x = R[k:, k].copy()
        alpha = norm(x)
        if alpha == 0.0:
            continue
        v = x.copy()
        v[0] += (1.0 if x[0] >= 0 else -1.0) * alpha
        beta = 2.0 / (v @ v)
        R[k:, :] -= beta * np.outer(v, v @ R[k:, :])
        Q[:, k:] -= beta * np.outer(Q[:, k:] @ v, v)
        R[k + 1:, k] = 0.0
    return Q, R


def back_substitution(U, b):
    """Solve U x = b for an upper-triangular square U.

    Args:
        U: (n x n) upper triangular.  b: length-n vector (or n x k matrix).
    Raises:
        ValueError: if some diagonal entry of U is exactly 0.
    """
    U = _as_float_matrix(U)
    b = np.array(b, dtype=float)
    n = U.shape[0]
    x = np.zeros_like(b)
    for i in range(n - 1, -1, -1):
        if U[i, i] == 0.0:
            raise ValueError("singular triangular matrix")
        x[i] = (b[i] - U[i, i + 1:] @ x[i + 1:]) / U[i, i]
    return x


def is_orthonormal(Q, tol=1e-10):
    """Return True if the columns of Q are orthonormal: max|Q^T Q - I| <= tol."""
    Q = _as_float_matrix(Q)
    k = Q.shape[1]
    return bool(np.max(np.abs(Q.T @ Q - np.eye(k)), initial=0.0) <= tol)


def projection_matrix(A):
    """Orthogonal projection matrix onto the column space of A.

    You may assume the columns of A are linearly independent.
    Returns the (m x m) matrix P with P = P^T = P @ P and P @ A == A.
    """
    A = _as_float_matrix(A)
    n = A.shape[1]
    Q, _ = qr_householder(A)
    Qn = Q[:, :n]
    return Qn @ Qn.T


def complete_basis(Q, tol=1e-10):
    """Extend orthonormal columns to a square orthogonal matrix.

    Args:
        Q: (m x k) array with orthonormal columns, 0 <= k <= m
           (k = 0 is allowed: Q has shape (m, 0)).
    Returns:
        (m x m) orthogonal matrix whose first k columns are exactly Q.
    """
    Q = _as_float_matrix(Q) if np.size(Q) else np.zeros(np.shape(Q))
    m, k = Q.shape
    cols = [Q[:, j] for j in range(k)]
    for i in range(m):
        if len(cols) == m:
            break
        w = np.zeros(m)
        w[i] = 1.0
        for _ in range(2):
            for q in cols:
                w -= (q @ w) * q
        nw = norm(w)
        if nw > tol:
            cols.append(w / nw)
    return np.column_stack(cols) if cols else np.zeros((m, 0))
