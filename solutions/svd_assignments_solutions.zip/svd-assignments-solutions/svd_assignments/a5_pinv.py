"""
Assignment 5 -- The pseudo-inverse and least squares.

Textbook: Chapters 8-9.   Lab Manual: Parts 5-6.

Rules: nothing from numpy.linalg (or scipy).  You may import your own
functions from a1-a4.
"""
import numpy as np

from .a2_orthogonal import qr_householder, back_substitution
from .a4_svd import svd_jacobi, matrix_rank

EPS = np.finfo(float).eps


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def pinv(A, rcond=None):
    """Moore-Penrose pseudo-inverse V Sigma^+ U^T of an (m x n) matrix.

    Singular values <= rcond * sigma_1 are treated as zero;
    default rcond = max(m, n) * EPS.  The result has shape (n x m);
    the pseudo-inverse of a zero matrix is the zero matrix.
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    U, s, Vt = svd_jacobi(A)
    if rcond is None:
        rcond = max(m, n) * EPS
    if s.size == 0 or s[0] == 0.0:
        return np.zeros((n, m))
    keep = s > rcond * s[0]
    inv = np.zeros_like(s)
    inv[keep] = 1.0 / s[keep]
    return (Vt.T * inv) @ U.T


def _solve(M, B):
    """Solve the square system M X = B with Householder QR."""
    Q, R = qr_householder(M)
    return back_substitution(R, Q.T @ B)


def pinv_full_rank(A):
    """Pseudo-inverse from the full-rank formulas (no SVD of A).

    independent columns:  (A^T A)^{-1} A^T
    independent rows:     A^T (A A^T)^{-1}
    Raises:
        ValueError: if A has neither independent columns nor independent rows.
    """
    A = _as_float_matrix(A)
    m, n = A.shape
    r = matrix_rank(A)
    if r == n:
        return _solve(A.T @ A, A.T)
    if r == m:
        return _solve(A @ A.T, A).T
    raise ValueError("A is rank deficient")


def penrose_residuals(A, X):
    """Return the Frobenius norms of the four Penrose residuals, as a tuple

        (||AXA - A||, ||XAX - X||, ||(AX)^T - AX||, ||(XA)^T - XA||).
    """
    A = _as_float_matrix(A)
    X = _as_float_matrix(X)
    AX, XA = A @ X, X @ A
    f = lambda M: float(np.sqrt(np.sum(M * M)))
    return (f(A @ X @ A - A), f(X @ A @ X - X), f(AX.T - AX), f(XA.T - XA))


def cholesky(S):
    """Lower-triangular L with L L^T = S.

    Raises:
        ValueError: if S is not (numerically) positive definite.
    """
    S = _as_float_matrix(S)
    n = S.shape[0]
    L = np.zeros((n, n))
    for j in range(n):
        d = S[j, j] - L[j, :j] @ L[j, :j]
        if d <= 0.0:
            raise ValueError("matrix is not positive definite")
        L[j, j] = np.sqrt(d)
        L[j + 1:, j] = (S[j + 1:, j] - L[j + 1:, :j] @ L[j, :j]) / L[j, j]
    return L


def lstsq_normal(A, b):
    """Least-squares solution from the normal equations A^T A x = A^T b,
    solved with your Cholesky factorisation.

    Raises:
        ValueError: if A^T A is not positive definite (dependent columns).
    """
    A = _as_float_matrix(A)
    L = cholesky(A.T @ A)
    y = A.T @ np.asarray(b, dtype=float)
    n = L.shape[0]
    z = np.zeros(n)
    for i in range(n):
        z[i] = (y[i] - L[i, :i] @ z[:i]) / L[i, i]
    return back_substitution(L.T, z)


def lstsq_qr(A, b):
    """Least-squares solution for A with independent columns, via Householder QR."""
    A = _as_float_matrix(A)
    n = A.shape[1]
    Q, R = qr_householder(A)
    return back_substitution(R[:n, :n], (Q.T @ np.asarray(b, dtype=float))[:n])


def lstsq_min_norm(A, b, rcond=None):
    """Minimum-norm least-squares solution A^+ b (works for any A)."""
    return pinv(A, rcond) @ np.asarray(b, dtype=float)
