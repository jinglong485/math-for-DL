"""
Assignment 1 -- Vectors and matrices from scratch.

Textbook: Chapters 1-2.   Lab Manual: Part 1.

Rules: use NumPy arrays and element-wise arithmetic only.  Do NOT use
anything from numpy.linalg (or scipy).  In this assignment you may not use
the @ operator, np.dot, np.matmul, np.inner, np.einsum or np.tensordot
either -- that is what you are implementing.
"""
import numpy as np


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def dot(u, v):
    """Return the dot product u . v as a Python float.

    Args:
        u, v: 1-D array-likes of the same length.
    Raises:
        ValueError: if the lengths differ.
    """
    u = np.asarray(u, dtype=float).ravel()
    v = np.asarray(v, dtype=float).ravel()
    if u.shape != v.shape:
        raise ValueError("vectors must have the same length")
    return float(np.sum(u * v))


def norm(x, p=2):
    """Return the p-norm of the vector x for p in {1, 2, np.inf}.

    The 2-norm must not overflow for entries as large as 1e200 and must not
    underflow to 0 for entries as small as 1e-200 (hint: scale by max|x_i|).
    The norm of an empty or zero vector is 0.0.

    Raises:
        ValueError: for any other p.
    """
    x = np.asarray(x, dtype=float).ravel()
    if p not in (1, 2, np.inf):
        raise ValueError("p must be 1, 2 or np.inf")
    if x.size == 0:
        return 0.0
    if p == 1:
        return float(np.sum(np.abs(x)))
    if p == np.inf:
        return float(np.max(np.abs(x)))
    s = np.max(np.abs(x))
    if s == 0.0:
        return 0.0
    return float(s * np.sqrt(np.sum((x / s) ** 2)))


def normalize(x):
    """Return the unit vector x / ||x||_2 as a float array.

    Raises:
        ValueError: if x is the zero vector.
    """
    x = np.asarray(x, dtype=float)
    n = norm(x)
    if n == 0.0:
        raise ValueError("cannot normalise the zero vector")
    return x / n


def angle(u, v):
    """Return the angle between u and v in radians, in [0, pi].

    Must never return nan, even when rounding makes the cosine slightly
    larger than 1 in absolute value.

    Raises:
        ValueError: if u or v is the zero vector.
    """
    nu, nv = norm(u), norm(v)
    if nu == 0.0 or nv == 0.0:
        raise ValueError("angle with the zero vector is undefined")
    c = dot(u, v) / (nu * nv)
    return float(np.arccos(np.clip(c, -1.0, 1.0)))


def project_onto_vector(b, a):
    """Return the orthogonal projection of b onto the line through a.

    Raises:
        ValueError: if a is the zero vector.
    """
    a = np.asarray(a, dtype=float)
    aa = dot(a, a)
    if aa == 0.0:
        raise ValueError("cannot project onto the zero vector")
    return (dot(a, b) / aa) * a


def outer(u, v):
    """Return the outer product u v^T, a (len(u) x len(v)) float array."""
    u = np.asarray(u, dtype=float).ravel()
    v = np.asarray(v, dtype=float).ravel()
    return u[:, None] * v[None, :]


def matmul(A, B):
    """Return the matrix product A B using loops (no @, np.dot, np.matmul ...).

    Args:
        A: (m x n) array-like.  B: (n x p) array-like.
    Returns:
        (m x p) float array.
    Raises:
        ValueError: if the inner dimensions do not match.
    """
    A = _as_float_matrix(A)
    B = _as_float_matrix(B)
    m, n = A.shape
    n2, p = B.shape
    if n != n2:
        raise ValueError("inner dimensions do not match")
    C = np.zeros((m, p))
    for i in range(m):
        for j in range(p):
            C[i, j] = np.sum(A[i, :] * B[:, j])
    return C


def rank_gaussian(A, tol=1e-10):
    """Return the rank of A by Gaussian elimination with partial pivoting.

    An entry counts as zero if its absolute value is <= tol * max(1, max|A|).
    """
    R = _as_float_matrix(A)
    m, n = R.shape
    thresh = tol * max(1.0, float(np.max(np.abs(R))) if R.size else 0.0)
    rank = 0
    for col in range(n):
        if rank == m:
            break
        p = rank + int(np.argmax(np.abs(R[rank:, col])))
        if abs(R[p, col]) <= thresh:
            continue
        R[[rank, p]] = R[[p, rank]]
        R[rank + 1:] -= np.outer(R[rank + 1:, col] / R[rank, col], R[rank])
        rank += 1
    return rank
