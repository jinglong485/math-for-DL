"""
Assignment 6 -- Applications: norms, low rank, regularisation, PCA.

Textbook: Chapters 7 and 10.   Lab Manual: Parts 6-7.

Rules: nothing from numpy.linalg (or scipy).  You may import your own
functions from a1-a5.
"""
import numpy as np

from .a4_svd import svd_jacobi, singular_values

EPS = np.finfo(float).eps


def _as_float_matrix(A):
    """Helper (given): return A as a 2-D float array copy (a 1-D input becomes a column)."""
    A = np.array(A, dtype=float)
    if A.ndim == 1:
        A = A.reshape(-1, 1)
    return A


def spectral_norm(A):
    """||A||_2 = sigma_1 (0.0 for the zero matrix)."""
    s = singular_values(A)
    return float(s[0]) if s.size else 0.0


def frobenius_norm(A):
    """||A||_F = sqrt(sum of squared entries) = sqrt(sum sigma_i^2)."""
    A = _as_float_matrix(A)
    return float(np.sqrt(np.sum(A * A)))


def nuclear_norm(A):
    """||A||_* = sum of the singular values."""
    return float(np.sum(singular_values(A)))


def condition_number(A):
    """kappa(A) = sigma_1 / sigma_r, where sigma_r is the smallest singular value
    above max(m, n) * EPS * sigma_1.  Return np.inf for the zero matrix."""
    A = _as_float_matrix(A)
    s = singular_values(A)
    if s.size == 0 or s[0] == 0.0:
        return np.inf
    s = s[s > max(A.shape) * EPS * s[0]]
    return float(s[0] / s[-1])


def low_rank_approx(A, k):
    """Best rank-k approximation sum_{i<k} sigma_i u_i v_i^T (Eckart-Young).

    k = 0 gives the zero matrix; k >= min(m, n) gives A itself.
    Raises:
        ValueError: if k < 0.
    """
    if k < 0:
        raise ValueError("k must be non-negative")
    A = _as_float_matrix(A)
    U, s, Vt = svd_jacobi(A)
    k = min(k, s.size)
    return (U[:, :k] * s[:k]) @ Vt[:k, :]


def eckart_young_error(s, k, norm="fro"):
    """Error ||A - A_k|| of the best rank-k approximation, from the singular values.

    Args:
        s: singular values in decreasing order.
        k: rank of the approximation (0 <= k).
        norm: "2" (spectral) or "fro" (Frobenius).
    Returns:
        sigma_{k+1} for norm "2" (0.0 if k >= len(s)),
        sqrt(sigma_{k+1}^2 + ...) for norm "fro".
    Raises:
        ValueError: for any other norm.
    """
    s = np.asarray(s, dtype=float).ravel()
    if norm == "2":
        return float(s[k]) if k < s.size else 0.0
    if norm == "fro":
        return float(np.sqrt(np.sum(s[k:] ** 2)))
    raise ValueError('norm must be "2" or "fro"')


def compression_ratio(m, n, k):
    """Storage of a rank-k truncated SVD relative to the full m x n matrix:
    k (m + n + 1) / (m n)."""
    return k * (m + n + 1) / (m * n)


def truncated_svd_solve(A, b, k):
    """TSVD solution sum_{i<k} (u_i^T b / sigma_i) v_i.

    Raises:
        ValueError: if k < 1 or k exceeds the number of non-zero singular values.
    """
    U, s, Vt = svd_jacobi(A)
    r = int(np.sum(s > 0))
    if k < 1 or k > r:
        raise ValueError("k must be between 1 and the rank of A")
    c = U[:, :k].T @ np.asarray(b, dtype=float)
    return Vt[:k].T @ (c / s[:k])


def ridge_solve(A, b, lam):
    """Tikhonov / ridge solution  argmin ||Ax - b||^2 + lam ||x||^2
    = sum_i sigma_i / (sigma_i^2 + lam) (u_i^T b) v_i.

    lam = 0 must give the minimum-norm least-squares solution A^+ b
    (terms with sigma_i = 0 contribute nothing).
    Raises:
        ValueError: if lam < 0.
    """
    if lam < 0:
        raise ValueError("lam must be non-negative")
    U, s, Vt = svd_jacobi(A)
    c = U.T @ np.asarray(b, dtype=float)
    f = np.zeros_like(s)
    nz = s > 0
    f[nz] = s[nz] / (s[nz] ** 2 + lam)
    return Vt.T @ (f * c)


def pca(X, k):
    """Principal component analysis of the rows of X (N samples x d features).

    Returns (components, explained_variance, scores, mean):
        components         (k x d)  rows are the principal directions v_1..v_k
        explained_variance (k,)     sigma_i^2 / (N - 1), decreasing
        scores             (N x k)  coordinates of the centred data: (X - mean) @ components.T
        mean               (d,)     the column means
    """
    X = _as_float_matrix(X)
    N = X.shape[0]
    mean = X.mean(axis=0)
    U, s, Vt = svd_jacobi(X - mean)
    comps = Vt[:k]
    return comps, s[:k] ** 2 / (N - 1), (X - mean) @ comps.T, mean
