# Matrix Calculus for Deep Learning — Reference Solutions

Reference implementations of all six assignments, with the same test suite
as the starter package. Open this only after you have a passing (or
abandoned) attempt of your own.

```bash
python -m pip install -r requirements.txt
python grade.py          # 100.0 / 100
```

`mc_assignments/` holds the solutions; `tests/`, `grade.py` and `pytest.ini`
are identical to the starter package, so you can also copy a single solution
module into your own folder to compare behaviour.

A few points the solutions illustrate:

* **General (non-symmetric) formulas.** The tests perturb single matrix
  entries, so gradients such as d ln|det X| / dX = X^{-T} are written for a
  general X. Values use `slogdet` and `solve`, never a Cholesky factor that
  reads only one triangle (see A3).
* **Stable forms everywhere.** log-sum-exp with the maximum subtracted,
  softplus via `log1p(exp(-|a|))`, sigmoid via `exp(-|a|)`, cross-entropy
  from log-probabilities.
* **Shapes as a check.** Every backward pass returns gradients shaped like
  the corresponding variables, which almost determines the formula.
* **Reverse mode in ~150 lines.** `a5_autodiff.Tensor` records parents and a
  backward closure per operation, orders the graph topologically and walks it
  once; `unbroadcast` handles NumPy broadcasting.
