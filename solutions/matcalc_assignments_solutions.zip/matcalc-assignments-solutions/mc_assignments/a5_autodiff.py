"""
Assignment 5 -- Automatic differentiation from scratch.

Textbook: Chapters 8-9.   Lab Manual: Part 5.

Part A: forward mode with dual numbers.
Part B: a reverse-mode Tensor class (a tiny autograd).
Rules: NumPy only.  No JAX / PyTorch / autograd.
"""
import numpy as np


# =====================================================================
# Part A -- forward mode
# =====================================================================

class Dual:
    """A dual number val + der * eps with eps^2 = 0.

    Must support +, -, *, / and ** (real exponent) with Duals AND plain
    numbers on either side (2 * d, d + 1, 1 / d, ...), and unary minus.
    """

    def __init__(self, val, der=0.0):
        self.val = float(val)
        self.der = float(der)

    @staticmethod
    def _lift(o):
        return o if isinstance(o, Dual) else Dual(o, 0.0)

    def __add__(self, o):
        o = Dual._lift(o)
        return Dual(self.val + o.val, self.der + o.der)

    def __radd__(self, o):
        return self + o

    def __sub__(self, o):
        o = Dual._lift(o)
        return Dual(self.val - o.val, self.der - o.der)

    def __rsub__(self, o):
        return Dual._lift(o) - self

    def __mul__(self, o):
        o = Dual._lift(o)
        return Dual(self.val * o.val, self.val * o.der + self.der * o.val)

    def __rmul__(self, o):
        return self * o

    def __truediv__(self, o):
        o = Dual._lift(o)
        return Dual(self.val / o.val, (self.der * o.val - self.val * o.der) / o.val ** 2)

    def __rtruediv__(self, o):
        return Dual._lift(o) / self

    def __neg__(self):
        return Dual(-self.val, -self.der)

    def __pow__(self, p):
        """d ** p for a plain real number p."""
        return Dual(self.val ** p, p * self.val ** (p - 1) * self.der)


def d_sin(x):
    """sin for Duals (and plain floats)."""
    return Dual(np.sin(x.val), np.cos(x.val) * x.der) if isinstance(x, Dual) else np.sin(x)


def d_cos(x):
    """cos for Duals (and plain floats)."""
    return Dual(np.cos(x.val), -np.sin(x.val) * x.der) if isinstance(x, Dual) else np.cos(x)


def d_exp(x):
    """exp for Duals (and plain floats)."""
    return Dual(np.exp(x.val), np.exp(x.val) * x.der) if isinstance(x, Dual) else np.exp(x)


def d_log(x):
    """Natural log for Duals (and plain floats)."""
    return Dual(np.log(x.val), x.der / x.val) if isinstance(x, Dual) else np.log(x)


def derivative(f, x):
    """f'(x) for a scalar function f, by one evaluation on the dual number x + 1 eps."""
    return f(Dual(x, 1.0)).der


def gradient_forward(f, x):
    """Gradient of f: R^n -> R in forward mode: n evaluations of f.

    f receives a LIST of n Duals and returns a Dual.  Returns a 1-D array.
    """
    x = np.asarray(x, dtype=float)
    g = np.zeros(len(x))
    for i in range(len(x)):
        g[i] = f([Dual(x[j], 1.0 if j == i else 0.0) for j in range(len(x))]).der
    return g


# =====================================================================
# Part B -- reverse mode
# =====================================================================

def unbroadcast(grad, shape):
    """Sum `grad` over the axes that NumPy broadcasting added or stretched, to get `shape`."""
    while grad.ndim > len(shape):
        grad = grad.sum(axis=0)
    for axis, n in enumerate(shape):
        if n == 1 and grad.shape[axis] != 1:
            grad = grad.sum(axis=axis, keepdims=True)
    return grad


class Tensor:
    """A float array that records the operations applied to it.

    Attributes: data (np.ndarray, float), grad (same shape, starts at 0).
    Required operations (each returns a NEW Tensor that knows its parents
    and how to send gradients back to them):
        a + b, a - b, a * b, a / b, -a        (Tensors or numbers, with broadcasting)
        a ** p                                 (p a real number)
        a @ b                                  (2-D matrices)
        a.T                                    (transpose)
        a.sum(axis=None), a.mean(axis=None)
        a.exp(), a.log(), a.tanh(), a.relu(), a.sigmoid()
    and t.backward() for a scalar (size-1) Tensor t, which fills .grad of
    every Tensor t depends on, ADDING to existing .grad values.

    Design (given in __init__): out._parents is the tuple of input Tensors and
    out._back is a function of no arguments that, when called, ADDS out.grad's
    contribution to each parent's .grad.  backward() orders the graph
    topologically and calls each node's _back once, from the output down.
    __add__ is done for you as a worked pattern (it needs unbroadcast).
    """

    def __init__(self, data, parents=()):
        self.data = np.array(data, dtype=float)
        self.grad = np.zeros_like(self.data)
        self._parents = parents
        self._back = lambda: None

    @property
    def shape(self):
        return self.data.shape

    @staticmethod
    def _lift(o):
        return o if isinstance(o, Tensor) else Tensor(o)

    def __add__(self, o):
        o = Tensor._lift(o)
        out = Tensor(self.data + o.data, (self, o))
        def back():
            self.grad += unbroadcast(out.grad, self.shape)
            o.grad += unbroadcast(out.grad, o.shape)
        out._back = back
        return out

    def __radd__(self, o):
        return self + o

    def __mul__(self, o):
        o = Tensor._lift(o)
        out = Tensor(self.data * o.data, (self, o))
        def back():
            self.grad += unbroadcast(out.grad * o.data, self.shape)
            o.grad += unbroadcast(out.grad * self.data, o.shape)
        out._back = back
        return out

    def __rmul__(self, o):
        return self * o

    def __neg__(self):
        return self * -1.0

    def __sub__(self, o):
        return self + (-Tensor._lift(o))

    def __rsub__(self, o):
        return Tensor._lift(o) + (-self)

    def __pow__(self, p):
        """a ** p for a plain real number p."""
        out = Tensor(self.data ** p, (self,))
        def back():
            self.grad += out.grad * p * self.data ** (p - 1)
        out._back = back
        return out

    def __truediv__(self, o):
        return self * Tensor._lift(o) ** -1.0

    def __rtruediv__(self, o):
        return Tensor._lift(o) * self ** -1.0

    def __matmul__(self, o):
        """Matrix product of 2-D Tensors."""
        o = Tensor._lift(o)
        out = Tensor(self.data @ o.data, (self, o))
        def back():
            self.grad += out.grad @ o.data.T
            o.grad += self.data.T @ out.grad
        out._back = back
        return out

    @property
    def T(self):
        """The transpose (a property: write a.T, not a.T())."""
        out = Tensor(self.data.T, (self,))
        def back():
            self.grad += out.grad.T
        out._back = back
        return out

    def sum(self, axis=None):
        """Sum of all entries (axis=None) or over one integer axis, like ndarray.sum."""
        out = Tensor(self.data.sum(axis=axis), (self,))
        def back():
            g = out.grad if axis is None else np.expand_dims(out.grad, axis)
            self.grad += np.broadcast_to(g, self.shape)
        out._back = back
        return out

    def mean(self, axis=None):
        """Mean of all entries (axis=None) or over one integer axis."""
        n = self.data.size if axis is None else self.data.shape[axis]
        return self.sum(axis) * (1.0 / n)

    def _unary(self, value, local):
        out = Tensor(value, (self,))
        def back():
            self.grad += out.grad * local
        out._back = back
        return out

    def exp(self):
        e = np.exp(self.data)
        return self._unary(e, e)

    def log(self):
        return self._unary(np.log(self.data), 1.0 / self.data)

    def tanh(self):
        t = np.tanh(self.data)
        return self._unary(t, 1 - t ** 2)

    def relu(self):
        """max(a, 0), with relu'(0) = 0."""
        return self._unary(np.maximum(self.data, 0.0), (self.data > 0).astype(float))

    def sigmoid(self):
        """1 / (1 + exp(-a)), without overflow for large |a|."""
        e = np.exp(-np.abs(self.data))
        s = np.where(self.data >= 0, 1 / (1 + e), e / (1 + e))
        return self._unary(s, s * (1 - s))

    def backward(self):
        """For a size-1 Tensor: ADD ones to self.grad, then call _back of every node
        in reverse topological order (each node exactly once)."""
        order, seen = [], set()
        def visit(v):
            if id(v) not in seen:
                seen.add(id(v))
                for p in v._parents:
                    visit(p)
                order.append(v)
        visit(self)
        self.grad = self.grad + np.ones_like(self.data)
        for v in reversed(order):
            v._back()


def cross_entropy(logits, y):
    """Mean softmax cross-entropy of a 2-D logits Tensor with integer labels y, as ONE
    primitive operation: stable forward pass, backward pass (S - T) / N."""
    A = logits.data
    N = A.shape[0]
    m = A.max(axis=1, keepdims=True)
    logp = A - m - np.log(np.exp(A - m).sum(axis=1, keepdims=True))
    y = np.asarray(y)
    out = Tensor(-np.mean(logp[np.arange(N), y]), (logits,))
    def back():
        G = np.exp(logp)
        G[np.arange(N), y] -= 1.0
        logits.grad += out.grad * G / N
    out._back = back
    return out
