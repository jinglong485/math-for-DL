"""
Assignment 3 -- Derivatives with respect to matrices; Gaussians.

Textbook: Chapters 6-7.   Lab Manual: Part 3.

Every function returns (value, gradient) where the gradient has the shape
of the variable.  Treat every entry of X as an independent variable (the
tests perturb single entries, so X may be non-symmetric even when it starts
symmetric).  Compute VALUES with solve / slogdet (not Cholesky, which reads
only one triangle).  numpy.linalg is allowed.
"""
import numpy as np


def trace_AX(X, A):
    """f = tr(A X)."""
    return float(np.trace(A @ X)), A.T.copy()


def trace_XtAX(X, A):
    """f = tr(X^T A X), A square and NOT necessarily symmetric."""
    return float(np.trace(X.T @ A @ X)), (A + A.T) @ X


def bilinear(X, a, b):
    """f = a^T X b."""
    return float(a @ X @ b), np.outer(a, b)


def logabsdet(X):
    """f = ln |det X| for invertible X (any sign of the determinant)."""
    return float(np.linalg.slogdet(X)[1]), np.linalg.inv(X).T


def det(X):
    """f = det X."""
    d = float(np.linalg.det(X))
    return d, d * np.linalg.inv(X).T


def trace_inv(X, A):
    """f = tr(X^{-1} A)."""
    Xi = np.linalg.inv(X)
    return float(np.trace(Xi @ A)), -(Xi @ A @ Xi).T


def inv_bilinear(X, a, b):
    """f = a^T X^{-1} b."""
    XiT = np.linalg.inv(X).T
    return float(a @ np.linalg.solve(X, b)), -XiT @ np.outer(a, b) @ XiT


def frobenius_lsq(X, A, B):
    """f = ||A X - B||_F^2."""
    R = A @ X - B
    return float(np.sum(R * R)), 2 * A.T @ R


def tanh_weighted(X, A):
    """f = sum_ij A_ij tanh(X_ij) = tr(A^T tanh(X))."""
    T = np.tanh(X)
    return float(np.sum(A * T)), A * (1 - T ** 2)


def gaussian_nll(X, mu, Sigma):
    """Negative log-likelihood of the rows of X (N x D) under N(mu, Sigma).

    value = N D/2 ln(2 pi) + N/2 ln|Sigma| + 1/2 sum_n (x_n-mu)^T Sigma^{-1} (x_n-mu)
    Returns (value, d/dmu, d/dSigma).
    """
    X = np.atleast_2d(X)
    N, D = X.shape
    diff = X - mu
    Si = np.linalg.inv(Sigma)
    S = diff.T @ diff
    value = 0.5 * N * D * np.log(2 * np.pi) + 0.5 * N * np.linalg.slogdet(Sigma)[1] \
        + 0.5 * float(np.sum(diff * np.linalg.solve(Sigma, diff.T).T))
    dmu = -0.5 * (Si + Si.T) @ diff.sum(axis=0)
    dSigma = 0.5 * (N * Si.T - Si.T @ S @ Si.T)
    return float(value), dmu, dSigma


def gaussian_mle(X):
    """Maximum-likelihood mean and covariance (divide by N). Returns (mu, Sigma)."""
    X = np.atleast_2d(X)
    mu = X.mean(axis=0)
    d = X - mu
    return mu, d.T @ d / X.shape[0]


def gaussian_conditional(mu, Sigma, idx_b, x_b):
    """Parameters of p(x_a | x_b) for x ~ N(mu, Sigma).

    idx_b: list of observed coordinates; a = the remaining coordinates in
    increasing order.  Returns (mu_cond, Sigma_cond).
    """
    D = len(mu)
    idx_b = list(idx_b)
    idx_a = [i for i in range(D) if i not in idx_b]
    Saa = Sigma[np.ix_(idx_a, idx_a)]
    Sab = Sigma[np.ix_(idx_a, idx_b)]
    Sbb = Sigma[np.ix_(idx_b, idx_b)]
    K = np.linalg.solve(Sbb, Sab.T).T            # Sab Sbb^{-1}
    mu_c = mu[idx_a] + K @ (np.asarray(x_b, dtype=float) - mu[idx_b])
    return mu_c, Saa - K @ Sab.T


def kl_gaussians(mu1, S1, mu2, S2):
    """KL( N(mu1, S1) || N(mu2, S2) ) for full covariance matrices (a float)."""
    D = len(mu1)
    d = mu2 - mu1
    return float(0.5 * (np.trace(np.linalg.solve(S2, S1)) + d @ np.linalg.solve(S2, d) - D
                        + np.linalg.slogdet(S2)[1] - np.linalg.slogdet(S1)[1]))


def kl_diag_standard(mu, logvar):
    """KL( N(mu, diag(exp(logvar))) || N(0, I) ) -- the VAE term.

    Returns (value, d/dmu, d/dlogvar).
    """
    var = np.exp(logvar)
    return 0.5 * float(np.sum(var + mu ** 2 - 1.0 - logvar)), np.array(mu, dtype=float), 0.5 * (var - 1.0)
