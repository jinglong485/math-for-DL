"""
Assignment 1 -- Gradient checking, functions of matrices, matrix identities.

Textbook: Chapters 1-3 and 9.1-9.2.   Lab Manual: Part 1.

Rules: NumPy only.  numpy.linalg (solve, inv, det, slogdet, cholesky, eigh)
is allowed.  No JAX, PyTorch, TensorFlow, autograd, SciPy.
"""
import numpy as np


def numerical_gradient(f, X, h=1e-6):
    """Central-difference gradient of a scalar function f at X.

    Args:
        f: function taking an array shaped like X and returning a float.
        X: array of any shape (the point).  It must NOT be modified.
        h: step size.
    Returns:
        Float array with the same shape as X whose entry idx is
        (f(X + h E_idx) - f(X - h E_idx)) / (2h).
    """
    X = np.array(X, dtype=float)
    G = np.zeros_like(X)
    for idx in np.ndindex(X.shape):
        old = X[idx]
        X[idx] = old + h
        fp = f(X)
        X[idx] = old - h
        fm = f(X)
        X[idx] = old
        G[idx] = (fp - fm) / (2 * h)
    return G


def numerical_jacobian(f, x, h=1e-6):
    """Central-difference Jacobian of f: R^n -> R^m.

    Inputs and outputs of any shape are flattened (row-major), so the
    result J has shape (m, n) with J[i, j] = d f_i / d x_j.
    """
    x = np.array(x, dtype=float)
    m = np.size(f(x))
    J = np.zeros((m, x.size))
    for j, idx in enumerate(np.ndindex(x.shape)):
        old = x[idx]
        x[idx] = old + h
        fp = np.ravel(f(x))
        x[idx] = old - h
        fm = np.ravel(f(x))
        x[idx] = old
        J[:, j] = (fp - fm) / (2 * h)
    return J


def relative_error(a, b):
    """||a - b|| / max(||a||, ||b||, 1e-12) with Frobenius (2-) norms, as a float."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    return float(np.linalg.norm(a - b) / max(np.linalg.norm(a), np.linalg.norm(b), 1e-12))


def logdet_spd(S):
    """ln det S for a symmetric positive definite S, computed from its Cholesky factor.

    Must work when det S under- or overflows (e.g. 0.1 * I of size 400).
    Raises:
        ValueError: if S is not positive definite.
    """
    try:
        L = np.linalg.cholesky(np.asarray(S, dtype=float))
    except np.linalg.LinAlgError:
        raise ValueError("matrix is not positive definite")
    return 2.0 * float(np.sum(np.log(np.diag(L))))


def sym_matrix_function(S, fn):
    """f(S) = Q f(Lambda) Q^T for a symmetric matrix S = Q Lambda Q^T.

    fn is applied element-wise to the 1-D array of eigenvalues.
    """
    w, Q = np.linalg.eigh(np.asarray(S, dtype=float))
    return (Q * fn(w)) @ Q.T


def sqrtm_psd(S):
    """The symmetric positive semidefinite square root of a PSD matrix.

    Tiny negative eigenvalues from rounding (>= -1e-12 * max|eigenvalue|)
    are treated as 0.
    """
    return sym_matrix_function(S, lambda w: np.sqrt(np.clip(w, 0.0, None)))


def inv_sqrtm_pd(S):
    """S^{-1/2} for a symmetric positive definite S (the whitening matrix)."""
    return sym_matrix_function(S, lambda w: 1.0 / np.sqrt(w))


def expm(A, terms=20):
    """Matrix exponential of ANY square matrix (not only symmetric ones).

    Use the Taylor series with scaling and squaring: the result must be
    accurate (relative error < 1e-10) even for matrices of norm ~ 20.
    """
    A = np.asarray(A, dtype=float)
    n = A.shape[0]
    nrm = np.max(np.sum(np.abs(A), axis=0)) if A.size else 0.0
    s = max(0, int(np.ceil(np.log2(nrm))) + 1) if nrm > 0 else 0
    B = A / 2.0 ** s
    E, T = np.eye(n), np.eye(n)
    for k in range(1, terms + 1):
        T = T @ B / k
        E = E + T
    for _ in range(s):
        E = E @ E
    return E


def sherman_morrison(Ainv, u, v):
    """(A + u v^T)^{-1}, given A^{-1}, in O(n^2) operations (no new inverse)."""
    Au = Ainv @ u
    vA = v @ Ainv
    return Ainv - np.outer(Au, vA) / (1.0 + v @ Au)


def woodbury(Ainv, U, C, V):
    """(A + U C V)^{-1}, given A^{-1}, solving only a k x k system (C is k x k)."""
    K = np.linalg.inv(C) + V @ Ainv @ U
    return Ainv - Ainv @ U @ np.linalg.solve(K, V @ Ainv)


def block_inverse(A, B, C, D):
    """Inverse of the block matrix [[A, B], [C, D]] via the Schur complement of D.

    Returns the full (p+q) x (p+q) inverse.
    """
    Dinv = np.linalg.inv(D)
    P = np.linalg.inv(A - B @ Dinv @ C)
    return np.block([[P, -P @ B @ Dinv], [-Dinv @ C @ P, Dinv + Dinv @ C @ P @ B @ Dinv]])


def block_logabsdet(A, B, C, D):
    """ln |det [[A, B], [C, D]]| = ln|det D| + ln|det(A - B D^{-1} C)|."""
    Dinv = np.linalg.inv(D)
    return float(np.linalg.slogdet(D)[1] + np.linalg.slogdet(A - B @ Dinv @ C)[1])
