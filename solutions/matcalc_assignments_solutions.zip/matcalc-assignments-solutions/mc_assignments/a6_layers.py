"""
Assignment 6 -- Deep-learning layers: attention, normalisation, flows, traces.

Textbook: Chapters 10-12.   Lab Manual: Part 6.

Rules: NumPy only (numpy.linalg allowed); every backward pass is derived by hand.
"""
import numpy as np


def softmax_rows(S):
    """Row-wise softmax of a 2-D array; rows full of -inf except one entry must work."""
    S = np.asarray(S, dtype=float)
    e = np.exp(S - np.max(S, axis=1, keepdims=True))
    return e / e.sum(axis=1, keepdims=True)


def softmax_rows_backward(A, dA):
    """Given A = softmax_rows(S) and dA = dL/dA, return dL/dS."""
    return A * (dA - np.sum(dA * A, axis=1, keepdims=True))


def attention_forward(X, Wq, Wk, Wv, causal=False):
    """One self-attention head: Y = softmax(Q K^T / sqrt(d_k)) V with Q=XWq, K=XWk, V=XWv.

    causal=True: token i may only attend to tokens j <= i.
    Returns (Y, cache) where cache is anything your backward pass needs.
    """
    Q, K, V = X @ Wq, X @ Wk, X @ Wv
    dk = Wq.shape[1]
    S = Q @ K.T / np.sqrt(dk)
    if causal:
        S = np.where(np.tril(np.ones(S.shape, dtype=bool)), S, -np.inf)
    A = softmax_rows(S)
    return A @ V, (X, Wq, Wk, Wv, Q, K, V, A, dk)


def attention_backward(dY, cache):
    """Returns (dX, dWq, dWk, dWv)."""
    X, Wq, Wk, Wv, Q, K, V, A, dk = cache
    dV = A.T @ dY
    dS = softmax_rows_backward(A, dY @ V.T)
    dQ = dS @ K / np.sqrt(dk)
    dK = dS.T @ Q / np.sqrt(dk)
    return dQ @ Wq.T + dK @ Wk.T + dV @ Wv.T, X.T @ dQ, X.T @ dK, X.T @ dV


def layernorm_forward(X, gamma, beta, eps=1e-5):
    """Normalise each ROW to mean 0, variance 1 (population variance), then gamma * xhat + beta.

    Returns (Y, cache).
    """
    mu = X.mean(axis=1, keepdims=True)
    sig = np.sqrt(X.var(axis=1, keepdims=True) + eps)
    Xh = (X - mu) / sig
    return gamma * Xh + beta, (Xh, sig, gamma)


def layernorm_backward(dY, cache):
    """Returns (dX, dgamma, dbeta)."""
    Xh, sig, gamma = cache
    g = dY * gamma
    dX = (g - g.mean(axis=1, keepdims=True) - Xh * (g * Xh).mean(axis=1, keepdims=True)) / sig
    return dX, (dY * Xh).sum(axis=0), dY.sum(axis=0)


def batchnorm_forward(X, gamma, beta, eps=1e-5):
    """Training-mode batch norm: normalise each COLUMN over the batch, then gamma * xhat + beta.

    Returns (Y, cache).
    """
    mu = X.mean(axis=0, keepdims=True)
    sig = np.sqrt(X.var(axis=0, keepdims=True) + eps)
    Xh = (X - mu) / sig
    return gamma * Xh + beta, (Xh, sig, gamma)


def batchnorm_backward(dY, cache):
    """Returns (dX, dgamma, dbeta)."""
    Xh, sig, gamma = cache
    g = dY * gamma
    dX = (g - g.mean(axis=0, keepdims=True) - Xh * (g * Xh).mean(axis=0, keepdims=True)) / sig
    return dX, (dY * Xh).sum(axis=0), dY.sum(axis=0)


def coupling_forward(x, Ws, bs, Wt, bt):
    """Affine coupling layer on the rows of x (N x D, D even, d = D/2):

        z_A = x_A,   z_B = x_B * exp(s) + t,
        s = tanh(x_A Ws + bs),  t = x_A Wt + bt     (Ws, Wt: d x d; bs, bt: d)

    with x_A = x[:, :d], x_B = x[:, d:].  Returns (z, logdet) where logdet[n]
    = ln |det dz_n/dx_n|.
    """
    d = x.shape[1] // 2
    xa, xb = x[:, :d], x[:, d:]
    s = np.tanh(xa @ Ws + bs)
    return np.hstack([xa, xb * np.exp(s) + xa @ Wt + bt]), s.sum(axis=1)


def coupling_inverse(z, Ws, bs, Wt, bt):
    """The exact inverse of coupling_forward."""
    d = z.shape[1] // 2
    za, zb = z[:, :d], z[:, d:]
    s = np.tanh(za @ Ws + bs)
    return np.hstack([za, (zb - za @ Wt - bt) * np.exp(-s)])


def linear_flow_nll(X, A, b):
    """Mean negative log-likelihood of the rows of X under x = A z + b, z ~ N(0, I).

    value = D/2 ln(2 pi) + mean_n 1/2 ||A^{-1}(x_n - b)||^2 + ln |det A|.
    Returns (value, dA, db).
    """
    N, D = X.shape
    Z = np.linalg.solve(A, (X - b).T).T
    AiT = np.linalg.inv(A).T
    value = 0.5 * D * np.log(2 * np.pi) + 0.5 * np.mean(np.sum(Z ** 2, axis=1)) + np.linalg.slogdet(A)[1]
    return float(value), AiT @ (np.eye(D) - Z.T @ Z / N), -AiT @ Z.mean(axis=0)


def hutchinson_trace(matvec, n, n_samples, rng):
    """Hutchinson estimate of tr(M) from n_samples Rademacher (+-1) vectors.

    matvec(v) returns M @ v; M itself is never available.  Draw each vector
    with rng.choice([-1.0, 1.0], size=n).  Returns the mean of eps^T M eps.
    """
    total = 0.0
    for _ in range(n_samples):
        e = rng.choice([-1.0, 1.0], size=n)
        total += e @ matvec(e)
    return total / n_samples


def rayleigh_quotient(S, x):
    """R(x) = x^T S x / x^T x for symmetric S, and its gradient. Returns (R, grad)."""
    xx = x @ x
    R = float(x @ S @ x / xx)
    return R, 2 * (S @ x - R * x) / xx


def top_eigenvector(S, n_steps=500, lr=0.5, seed=0):
    """Top eigenvector of symmetric PSD S by gradient ASCENT on the Rayleigh quotient,
    renormalising to unit length after each step, starting from a random unit vector
    drawn with np.random.default_rng(seed). Returns (eigenvalue, unit eigenvector)."""
    x = np.random.default_rng(seed).standard_normal(S.shape[0])
    x /= np.linalg.norm(x)
    scale = max(np.abs(S).max(), 1e-300)
    for _ in range(n_steps):
        _, g = rayleigh_quotient(S, x)
        x = x + lr * g / scale
        x /= np.linalg.norm(x)
    return rayleigh_quotient(S, x)[0], x
