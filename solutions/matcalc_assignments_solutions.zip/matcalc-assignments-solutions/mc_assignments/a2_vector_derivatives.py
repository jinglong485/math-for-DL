"""
Assignment 2 -- Derivatives with respect to vectors; curvature and optimisation.

Textbook: Chapters 4-5.   Lab Manual: Part 2.

Rules: NumPy only (numpy.linalg allowed).  Every function that returns a
gradient or Hessian must compute it from your own formula, not numerically.
"""
import numpy as np


def quadratic(x, A, b):
    """f(x) = x^T A x + b^T x for a square (NOT necessarily symmetric) A.

    Returns (f, gradient, Hessian) as (float, (n,) array, (n, n) array).
    """
    x = np.asarray(x, dtype=float)
    return float(x @ A @ x + b @ x), (A + A.T) @ x + b, A + A.T


def least_squares(w, Phi, t, lam=0.0):
    """E(w) = 1/2 ||Phi w - t||^2 + lam/2 ||w||^2.  Returns (E, gradient, Hessian)."""
    r = Phi @ w - t
    E = 0.5 * float(r @ r) + 0.5 * lam * float(w @ w)
    return E, Phi.T @ r + lam * w, Phi.T @ Phi + lam * np.eye(len(w))


def ridge_solution(Phi, t, lam):
    """The minimiser (Phi^T Phi + lam I)^{-1} Phi^T t, computed with a solve."""
    return np.linalg.solve(Phi.T @ Phi + lam * np.eye(Phi.shape[1]), Phi.T @ t)


def logsumexp(a, axis=-1):
    """ln sum_k exp(a_k) along `axis`, without overflow (a may contain 1e4)."""
    a = np.asarray(a, dtype=float)
    m = np.max(a, axis=axis, keepdims=True)
    return np.squeeze(m + np.log(np.sum(np.exp(a - m), axis=axis, keepdims=True)), axis=axis)


def softmax(a, axis=-1):
    """Softmax along `axis`, without overflow."""
    a = np.asarray(a, dtype=float)
    e = np.exp(a - np.max(a, axis=axis, keepdims=True))
    return e / np.sum(e, axis=axis, keepdims=True)


def softmax_jacobian(a):
    """Jacobian of softmax at a 1-D vector a: diag(s) - s s^T."""
    s = softmax(a)
    return np.diag(s) - np.outer(s, s)


def sigmoid(a):
    """Logistic sigmoid 1/(1+exp(-a)), element-wise, never overflowing (a may be +-1e4)."""
    a = np.asarray(a, dtype=float)
    e = np.exp(-np.abs(a))
    return np.where(a >= 0, 1.0 / (1.0 + e), e / (1.0 + e))


def logistic_loss(w, Phi, t):
    """Cross-entropy E(w) = -sum[t ln y + (1-t) ln(1-y)], y = sigmoid(Phi w).

    Returns (E, gradient, Hessian).  E must be finite even when some
    |Phi w| ~ 1000 (compute it from the logits, not from y).
    """
    a = Phi @ w
    E = float(np.sum(np.maximum(a, 0) + np.log1p(np.exp(-np.abs(a))) - t * a))
    y = sigmoid(a)
    return E, Phi.T @ (y - t), Phi.T @ (Phi * (y * (1 - y))[:, None])


def normalize_jacobian(x):
    """Jacobian of g(x) = x / ||x|| at a non-zero x:  (I - x x^T / ||x||^2) / ||x||."""
    x = np.asarray(x, dtype=float)
    n = np.sqrt(x @ x)
    return (np.eye(len(x)) - np.outer(x, x) / n ** 2) / n


def gd_convergence_factor(H, lr):
    """Per-step error factor max_i |1 - lr * lambda_i| of gradient descent on 1/2 w^T H w (H symmetric)."""
    lam = np.linalg.eigvalsh(H)
    return float(np.max(np.abs(1.0 - lr * lam)))


def optimal_learning_rate(H):
    """The fixed step 2 / (lambda_min + lambda_max) for symmetric positive definite H."""
    lam = np.linalg.eigvalsh(H)
    return float(2.0 / (lam[0] + lam[-1]))


def newton_logistic(Phi, t, n_steps=10):
    """Logistic regression by Newton's method (IRLS) from w = 0. Returns w after n_steps."""
    w = np.zeros(Phi.shape[1])
    for _ in range(n_steps):
        _, g, H = logistic_loss(w, Phi, t)
        w = w - np.linalg.solve(H, g)
    return w
