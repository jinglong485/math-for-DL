"""
Assignment 4 -- Backpropagation: layers and a multilayer perceptron.

Textbook: Chapter 8.   Lab Manual: Part 4.

Conventions:
  * a mini-batch is a 2-D array with one example per ROW;
  * layer.forward(X) returns the output and stores what backward needs;
  * layer.backward(dY) receives dL/dY (shape of the output), stores the
    parameter gradients (layer.dW, layer.db) and returns dL/dX;
  * params() / grads() return lists of arrays in the same order.
Rules: NumPy only; no automatic differentiation.
"""
import numpy as np


class Linear:
    """Y = X W + b with W of shape (d_in, d_out) and b of shape (d_out,).

    Initialise W with rng.standard_normal((d_in, d_out)) * sqrt(1 / d_in)
    and b with zeros.
    """

    def __init__(self, d_in, d_out, rng):
        self.W = rng.standard_normal((d_in, d_out)) * np.sqrt(1.0 / d_in)
        self.b = np.zeros(d_out)

    def forward(self, X):
        self.X = X
        return X @ self.W + self.b

    def backward(self, dY):
        self.dW = self.X.T @ dY
        self.db = dY.sum(axis=0)
        return dY @ self.W.T

    def params(self):
        return [self.W, self.b]

    def grads(self):
        return [self.dW, self.db]


class ReLU:
    """H = max(Z, 0).  Use the convention ReLU'(0) = 0."""

    def forward(self, Z):
        self.mask = Z > 0
        return Z * self.mask

    def backward(self, dH):
        return dH * self.mask

    def params(self):
        return []

    def grads(self):
        return []


class Tanh:
    """H = tanh(Z)."""

    def forward(self, Z):
        self.H = np.tanh(Z)
        return self.H

    def backward(self, dH):
        return dH * (1 - self.H ** 2)

    def params(self):
        return []

    def grads(self):
        return []


class Sigmoid:
    """H = 1 / (1 + exp(-Z)), computed without overflow for |Z| up to 1e4."""

    def forward(self, Z):
        e = np.exp(-np.abs(Z))
        self.H = np.where(Z >= 0, 1 / (1 + e), e / (1 + e))
        return self.H

    def backward(self, dH):
        return dH * self.H * (1 - self.H)

    def params(self):
        return []

    def grads(self):
        return []


class MSELoss:
    """L = 1/(2N) ||Y - T||_F^2 for N rows.  forward(Y, T) -> float; backward() -> dL/dY."""

    def forward(self, Y, T):
        self.diff = Y - T
        return float(0.5 * np.sum(self.diff ** 2) / Y.shape[0])

    def backward(self):
        return self.diff / self.diff.shape[0]


class SoftmaxCrossEntropy:
    """Mean cross-entropy of softmax(A) (row-wise) with integer labels y.

    forward(A, y) -> float (stable for logits of size 1e4); backward() -> dL/dA.
    """

    def forward(self, A, y):
        N = A.shape[0]
        m = A.max(axis=1, keepdims=True)
        logp = A - m - np.log(np.exp(A - m).sum(axis=1, keepdims=True))
        self.S, self.y = np.exp(logp), np.asarray(y)
        return float(-np.mean(logp[np.arange(N), self.y]))

    def backward(self):
        N = self.S.shape[0]
        G = self.S.copy()
        G[np.arange(N), self.y] -= 1.0
        return G / N


class MLP:
    """Linear -> act -> Linear -> act -> ... -> Linear, with softmax cross-entropy.

    sizes: e.g. [2, 64, 64, 3]; activation: "tanh" or "relu".
    Create the Linear layers in order with ONE rng = np.random.default_rng(seed).
    """

    def __init__(self, sizes, activation="tanh", seed=0):
        rng = np.random.default_rng(seed)
        Act = {"tanh": Tanh, "relu": ReLU}[activation]
        self.layers = []
        for i, (a, b) in enumerate(zip(sizes[:-1], sizes[1:])):
            self.layers.append(Linear(a, b, rng))
            if i < len(sizes) - 2:
                self.layers.append(Act())
        self.loss_fn = SoftmaxCrossEntropy()

    def forward(self, X):
        """Return the logits."""
        for layer in self.layers:
            X = layer.forward(X)
        return X

    def loss(self, X, y):
        """Forward pass plus loss; must be called before backward()."""
        return self.loss_fn.forward(self.forward(X), y)

    def backward(self):
        """Backpropagate from the loss; fills every layer's grads and returns dL/dX."""
        g = self.loss_fn.backward()
        for layer in reversed(self.layers):
            g = layer.backward(g)
        return g

    def params(self):
        return [p for layer in self.layers for p in layer.params()]

    def grads(self):
        return [g for layer in self.layers for g in layer.grads()]


def train(model, X, y, lr=0.2, epochs=2000, momentum=0.9):
    """Full-batch gradient descent with momentum, updating model.params() IN PLACE.

    v <- momentum * v - lr * grad;  p <- p + v.   Returns the list/array of
    losses, one per epoch (the loss before that epoch's update).
    """
    vel = [np.zeros_like(p) for p in model.params()]
    hist = []
    for _ in range(epochs):
        hist.append(model.loss(X, y))
        model.backward()
        for p, g, v in zip(model.params(), model.grads(), vel):
            v *= momentum
            v -= lr * g
            p += v
    return np.array(hist)


def accuracy(model, X, y):
    """Fraction of rows whose largest logit is at the true label."""
    return float(np.mean(np.argmax(model.forward(X), axis=1) == y))
